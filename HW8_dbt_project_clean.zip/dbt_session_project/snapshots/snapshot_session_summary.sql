{% snapshot snapshot_session_summary %}
{{
    config(
      target_schema='ANALYTICS',
      unique_key='sessionId',
      strategy='timestamp',
      updated_at='ts',
      invalidate_hard_deletes=True
    )
}}
select * from {{ ref('session_summary') }}
{% endsnapshot %}
